from flask import Flask , render_template , request
#Flask의 역활 파이썬 코드와 웹서버 연동
app = Flask(__name__)

@app.route("/") #나의 접속 주소 하면 return 페이지에 접속을 해준다.
def Homepage():
    return render_template("member_register.html")

    #주소 + 담당자 + 나에게 줄것(페이지) 프레임 워크 공식*

@app.route('/member_register/',methods=["GET","POST"])
# methods=["get","post"]) 쓴 이유 데이터가 올때 get,post어느것이 올지 몰라서 둘다 쓴다.
def Homepage1():

    uid = request.args.get("uid")
    print(request.args.get("upw"))  #print를 쓴 이유는 데이터가 전달되나 cmd에서 확인을 하기 위해서 이다.
    request.args.get("uname")
    request.args.get("uphone") #request.args.get 이러면 get으로 받을수있다
    request.args.get("uaddr") #method가 get일때 정보를 넘길수있는 함수
    """
    print(request.form["uid"]) 
    #request 자체는 post만 받을수있다. get으로 받으려면 args get을 사용한다,
    print(request.form["upw"]) 
    print(request.form["uname"]) 
    print(request.form["uphone"]) 
    print(request.form["uaddr"]) 
    """
    #erquest에 빨간불이 드는것은 import를 안해서이다 request를 통해서 uid의 정보를 받는다.
    #cmd 창에서 정보가 넘어갔는지를 확인할수가 있다
    return render_template("temp.html",
    html_uid = uid)

app.run(debug=True) # 프로그램을 실행한다.




