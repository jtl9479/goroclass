from  flask  import  Flask , render_template, request
app=Flask(__name__)

@app.route("/pro_register/")
def ProRegisterPage( ):
 return render_template("pro_register.html")
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++
@app.route("/pro_register_db/",methods=["get","post"])
def HomePage2( ):


 pro_no     = request.form["no"]
 pro_name_tmp   = request.form["pro_name"]
 pro_price_tmp  = request.form["pro_price"]
 pro_expired_tmp = request.form["pro_expired"]

#대아토 베이스와 연결해줄 드라이버이다(커낵터라고 부른다)
#이것은 pip install mysql-connector 을 통해서 설치를 했다.
 import mysql.connector #디비와 파이썬을 직접적으로 연결하는 코드
 import mysql
 #dbconfig={'host':'localhost','user':'root','password':'','database':'bugger_prince_db'}
 dbconfig={'host':'localhost','user':'root','password':'','database':'product_db'}
 conn=mysql.connector.connect(**dbconfig)#원래 문법 외우면 된다.
 #-->디비와 파이썬을 연결하는 코드
 cursor=conn.cursor() 
 #SQL="SELECT p_no, p_name FROM bugger_prince_t" #햄버거 정보를 가지고있는 테이블이름
 """
 SQL = "insert into product(p_no,p_name,p_price) values(12,'kkk',10000)"
 #SQL = "SELECT * FROM product_info"
 cursor.execute(SQL)
 conn.commit
 """
 SQL=" INSERT INTO product (p_no,p_name,p_price) VALUES (2111,'rkskekfk',200);"

 cursor.execute(SQL) 

 conn.commit()
 #dbconfig=commit
 #cursor.commit()
 #dbconfig.close()
#############################################################

 return render_template("pro_register_display.html", 
                       
                       
                        html_pro = pro_no,
                        html_pro_name = pro_name_tmp,
                        html_pro_price = pro_price_tmp,
                        html_pro_expired = pro_expired_tmp)
                        
app.run(debug=True)