from flask import Flask, render_template, request
app = Flask(__name__)
########################
@app.route('/add_member/')
def add_member_con()->'html':
  #여기서 특별히 할일은 없어보임.
 return render_template('add_member.html')
#######################
@app.route('/add_member_sql/', methods=['POST'])
def add_member_sql()->'html':
 #전송받은 데이터들을 저장해둔다.
 no = request.form['no']
 name = request.form['name'] 
 tel = request.form['tel'] 
 addr = request.form['addr'] 
 email = request.form['email'] 
 postdata = []
 postdata.append(no)
 postdata.append(name)
 postdata.append(tel)
 postdata.append(addr)
 postdata.append(email)
 print( postdata )

 #데이터베이스 접속 및 저장 (전송받은 데이터들을 저장함)
 import mysql
 import mysql.connector
 dbconfig={'host':'localhost' , 'user':'root' , 'password':'', 'database':'members_d'}
 conn=mysql.connector.connect(**dbconfig)
 cursor=conn.cursor()
 #---------------------------------------------------------
 __SQL__="""INSERT INTO members_t (no, name, tel, addr, email )
  VALUES (%s , %s, %s, %s, %s)"""
 datapack = ( no,name,tel,addr,email )
 #---------------------------------------------------------
 cursor.execute(__SQL__ , datapack )
 conn.commit()
 cursor.close()
 conn.close()
 #마지막으로, 이 사람이 보내준 결과를 화면에 모두 출력해서 보여주고 잘저장되었다는 메시지를 출력한다!!
 return render_template('add_member_result.html')
########################
@app.route('/list_members/')
def list_members_con()->'html':
 # 데이터베이스에서 모든데이터를 가져온다(SELECT)
 # 가져온 데이터들은 sql_result 에 저장된다.
 #아래의 파이선 반복문이 그것들을 전부 cmd창에 출력해줄것이다.

 #실제로 검색된 모든데이터들은 아래와같이 저장된다. (리스트속의 리스트)
 #때문에, for문을 사용해서 그것들을 한줄씩 추출해내는 과정이필요함, 그리고 다시 한칸씩 출력해줘야함.
 sql_result = [ [100,'lee','010','seoul','lee@naver.com'] , [102,'kim','010','jeju','www@gmail.com']  ]
 for rec in sql_result:
  print(rec[0])
  print(rec[1])
  print(rec[2])
  print(rec[3])
  print(rec[4])
 return render_template('/list_members.html')
########################
app.run(debug=True)