﻿#웹서버내장된 홈페이지제작툴같은것(flask)
#파이선세계에서 가장유명한 두가지 홈페이지제작툴
# flask(중.소형) , Django(대형웹사이트전문)
from flask import Flask, render_template, request
import sqlite3
#그 제작툴의 기능을 사용할수있도록 객체를뽑아냄.
#app객체하나에 그모든기능이 담겨있음.
app=Flask(__name__)
#이주소(/home/)로 접속하면 내가담당한다.
#++++++++++++++++++++++++
# /adduser_db/ 접속시 담당자임
# 이건 그냥 adduser.html 페이지보내줌
@app.route('/',methods=['POST'])
def adduser_db_con()->"html":
 un=request.form['uname']
 ut=request.form['utel']
 ui=request.form['uid']
 up=request.form['upw']
#-------------------------
 import sqlite3 
 try:
  print("adduser 작동중....") 
  con = sqlite3.connect("./member.db ") 
  cur = con.cursor()
  cur.execute("INSERT INTO members_t values(?,?,?,?)",(un,ut,ui,up))
  con.commit() 
 except sqlite3.Error as er:
  print("에러발생"+str(er))
#-------------------------

 #이 데이터들을 html에 출력하려면, JINJA2 라는 문법이필요함.
 return render_template("temp.html",_uname_=un,_utel_=ut,_uid_=ui,_upw_=up)
#++++++++++++++++++++++++
@app.route('/adduser/')
def adduser_con()->"html":#담당자
 """
 import sqlite3 
 try:
  print("adduser 작동중....") 
  con = sqlite3.connect("./member.db ") 
  cur = con.cursor()
  cur.execute("INSERT INTO members_t values('kim','010-5555','admin','1234')")
  con.commit() 
 except sqlite3.Error as er:
  print("에러발생"+str(er))
 """
 return render_template("adduser.html")
#++++++++++++++++++++++++
@app.route('/home/')
def home_controller()->"html":#담당자
 #여기서 데이터베이스에 접속만해본다.(작동확인)
 con=sqlite3.connect("./member.db ") 
 print("파이선컨트롤러 작동중..데이터베이스체크중..")
 return render_template("homepage.html")#결과출력(브라우저)
#++++++++++++++++++++++++
@app.route('/home2/')
def home_controller2()->"html":#담당자
 print("파이선컨트롤러2 작동중.")    
 return render_template("homepage2.html")#결과출력(브라우저)
#++++++++++++++++++++++++
app.run(debug=True)#웹서버작동시킴